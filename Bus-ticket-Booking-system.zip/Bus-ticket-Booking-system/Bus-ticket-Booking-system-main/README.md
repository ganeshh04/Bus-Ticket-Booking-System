# Bus-ticket-Booking-system
This project allows users to select the bus and the seat they want to sit in and let them book the tickets.
It also has an Anmin panel which can only be accessed by the admin and he is able to add new busses

User can : 

-> Sign Up: They can create an account

->Search busses: They can choose busses by choosing the depart locations and destinations

->See bus details: They can see the timings of the bus like type,time of departure

->Select seat: They can select the seat they want to and book it

Admin can : 

->Admin Login : Login into the admin account which is secure

->Add Bus : Add a new bus with its timings type and its route
